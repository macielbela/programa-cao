let figura= prompt("insira uma figura geométrica para calcular a área (quadrado, retângulo ou círculo");
switch(figura) {

   case "quadrado":
      let lado1= parseFloat(prompt("insira a base do quadrado:"));
      let lado2= parseFloat(prompt("insira a altura do quadrado"));
      alert(`a área do quadrado é: ${lado1*lado2.toFixed(2)}.`);
      break;

      case "retângulo":
       let base= parseFloat(prompt("insira a base do retângulo:"));
       let altura= parseFloat(prompt("insira a altura do retângulo"));
       alert(`a área do retângulo é: ${base*altura.toFixed(2)}.`);
      break;

      case "círculo":
      let raio= parseFloat(prompt("insira o raio do círculo:"));
      alert(`a área do círculo é ${3.14*(raio*raio).toFixed(2)}`);
      break;

      default:
         alert("figura não encontrada.");
}