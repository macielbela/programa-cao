let numero= parseInt(prompt("insira um número de 1 a 7, que será correspondente a um dia da semana:"));
switch (numero) {
    case 1:
        alert("domingo");
    break;
    case 2:
        alert("segunda-feira")
    break;
    case 3:
        alert("terça-feira");
    break;
    case 4:
        alert("quarta-feira");
    break;
    case 5:
        alert("quinta-feira");
    break;
    case 6:
        alert("sexta-feira");
    break;
    case 7:
        alert("sábado");
    break;
    default:
        alert("número inválido. insira um número de 1 a 7");
}