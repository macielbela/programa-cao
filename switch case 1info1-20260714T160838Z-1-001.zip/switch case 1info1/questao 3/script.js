let mensagem = prompt("insira o seu período (manhã, tarde ou noite):");

switch (mensagem.toUpperCase()) {
    case "M":
    alert("bom dia! que cada desafio seja superado com determinação e coragem neste novo dia e que a gratidão invada o seu coração. bom dia, guerreiro!☀️");
    break;
    case "T":
    alert("boa tarde! linda tarde para você que, com alegria, espalha amor e carinho todos os dias!🌤️☕");
    break;
    case "N":
    alert("boa noite fofucho! espero que sua noite seja mágica e que você tenha um lindo amanhecer. boa noite!🫣🌛");
    break;
}