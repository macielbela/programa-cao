                                   let numero1= parseFloat(prompt("insira o primeiro número"));
let numero2= parseFloat(prompt("insira o segundo número"));
let operacao= prompt("insira uma operação. /= divisão, *= multiplicação, + ou -");

switch (operacao) {
    case "+":
    alert(`o resultado é ${numero1 + numero2.toFixed(2)}`);
    break;
        case "-":
    alert(`o resultado é ${numero1 - numero2.toFixed(2)}`);
    break;
        case "*":
    alert(`o resultado é ${numero1 * numero2.toFixed(2)}`);
    break;
        case "/":
    alert(`o resultado é ${numero1 / numero2.toFixed(2)}`);
    break;
    default:
        alert("caractere inválido. tente novamente");
}