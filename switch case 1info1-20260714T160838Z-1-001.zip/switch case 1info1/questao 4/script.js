let codigo = prompt("insira o código da sua bebida:");

switch (codigo) {
    case 1:
    alert("sua bebida é água🥤");
    break;
    case "2":
    alert("sua bebida é refrigerante🥃");
    break;
    case "3":
    alert("sua bebida é suco🧃");
    break;
    default:
}