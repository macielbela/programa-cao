let cod = parseInt(prompt("insira o código do seu produto:"))
switch (cod) {
   case 100:
      alert(" o seu produto é um mouse, e o preço dele é R$50.00");
   break;
   case 200:
      alert(" o seu produto é um teclado, e o preço dele é R$80.00");
   break;
   case 300:
      alert(" o seu produto é um monitor, e o preço dele é R$900.00");
   break;
   default:
     alert("código inválido.")
}