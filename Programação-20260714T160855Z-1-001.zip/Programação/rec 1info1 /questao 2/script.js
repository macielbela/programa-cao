let paginas= parseFloat(prompt("Infome a quanidade total de páginas a serem digitadas."));
let digitadores= parseFloat(prompt("Informe o número de digitadores trabalhando atualmente"));
let tempoConclusao= parseFloat(prompt("Informe o tempo total estimado para concluir o trabalho (em horas):"));
let digitadoresN=parseFloat(prompt("Informe o número de novos digitadores adicionados à empresa"))

let paginasHora= (paginas/digitadores)/tempoConclusao;
let digitadoresTotal= digitadores + digitadoresN;
let novoTempo = paginas / (paginasHora * digitadoresTotal);

alert(`A quantidade média de páginas digitadas por hora é de ${paginasHora.toFixed(2)} páginas.`);
alert(`o novo número de digitadores é de ${digitadoresTotal.toFixed(2)} digitadores.`);
alert(`O novo tempo estimado é de ${novoTempo.toFixed(2)} horas`);