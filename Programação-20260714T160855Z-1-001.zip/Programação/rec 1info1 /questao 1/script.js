let area= parseFloat(prompt("Infome a área total irrigada (em metros quadrados)"));
let agua= parseFloat(prompt("Informe a quantidade total de água utilizada (em litros)"));
let areaSetor= parseFloat(prompt("Àrea de um setor específico (em metros quadrados)"));

let consumoM2= agua/area;
let aguaTotal=areaSetor*consumoM2;
let dferenca= 500-agua;

alert(`O consumo de água em metros quadrados é de ${consumoM2.toFixed(2)} m².`);
alert(`A quantidade total de água utilizada no setor é de ${aguaTotal.toFixed(2)} litros.`);
alert(`A diferença do consumo do setor e 500 litros é de ${diferenca.toFixed(2)}`);