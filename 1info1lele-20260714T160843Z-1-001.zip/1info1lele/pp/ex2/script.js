let valorc = parseFloat(prompt("Valor das compras em R$"))
let fidelidade = (prompt("Qual seu nível fidelidade? B, P ou O?")).toUpperCase()
let cupom = (prompt("Seu cupom é valido ou não? Responda com S ou N")).toUpperCase()
let porcentagem
let valort

if (fidelidade == "O") {
    porcentagem = valorc * 0.15
    valort = valorc - porcentagem
    if (valort >= 150) {
        alert(`Sua compra ficou R$${valort} com desconto de cliente ouro \n e por causa desse valor, o frete é grátis `)
    }
    else {
         alert(`Sua compra ficou R$${valort} com desconto de cliente ouro \n e o frete ficou R$10,00. Resultando em ${valort + 10}`)
    }
   
}

else if (fidelidade == "P") {
    if (cupom == "S") {
        porcentagem = valorc * 0.10
        valort = valorc - porcentagem
    }
    else {
        porcentagem = valorc * 0.05
        valort = valorc - porcentagem
    }
    if (valorc > 250) {
        alert(`Sua compra ficou R$${valort} com desconto de cliente prata de 10% se o cupom é valido e 5% se não`)
    }
    else {
        alert(`Sua compra ficou R$${valort} com R$20 de frete fica: R$${valort + 20}, e desconto de cliente prata de 10% se o cupom é valido e 5% se não`)
    }

}

else {
    if (cupom == "S") {
        porcentagem = 0.05 * valorc
        valort = valorc - porcentagem
    }
    alert(`Sua compra ficou R$${valort} com R$30 de frete fica: R$${valort + 30} , e desconto de cliente prata de 10% se o cupom é valido e 5% se não`)
}


/*


○ Só ganha desconto se o cupom for válido (5% de desconto). Se for
inválido, não há desconto (0%).
○ O frete possui valor fixo de R$ 30,00 para qualquer situação.
Entradas:
● valorBruto
● nivelFidelidade
● cupomValido
Saídas:
● Valor do desconto aplicado (em R$).
● Valor do frete (em R$).
● Valor total final a ser pago pelo cliente (Valor Bruto - Desconto + Frete)*/