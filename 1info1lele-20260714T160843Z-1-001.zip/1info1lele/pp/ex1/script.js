let idade = parseInt(prompt("Insira a sua idade"))
let acidentes = parseInt(prompt("Histórico de acidentes nos últimos 3 anos (número inteiro)"))
let freio = prompt("Possui freio ABS e Airbag? S ou N").toUpperCase()

if (idade < 25 || acidentes > 2) {
    alert(`Sua multa é um Valor Mensal de: R$ 450,00.`)
    if (freio == "N") {
        alert(`Seu veículo não conta com freios apropriados, taxa extra de R$ 100,00. \n  Taxa final de R$ ${450 + 100}`)
    }
}

else if ((idade >= 25 && 2>acidentes>1) || idade < 25 && acidentes == 0) {
    alert(`Perfil de Risco Moderado e Valor Mensal: R$ 300,00`)
    if (freio == "N") {
        alert(`Seu veículo não conta com freios apropriados, taxa extra de R$ 100,00. \n  Taxa final de R$ ${300 + 100}`)
    }
    else if (freio == "S") {
        alert(`desconto de R$ 30,00. \n  Taxa final de R$ ${300 - 30}`)
    }
}

else {
    alert(`Perfil de Risco Baixo (Excelente Condutor). Valor Mensal: R$ 180,00.`)
}






/*
2. Risco Moderado: Motoristas com 25 anos ou mais que tenham exatamente 1
ou 2 acidentes no histórico, OU motoristas com menos de 25 anos mas com
histórico zerado de acidentes.
○ Mensagem: "Perfil de Risco Moderado."
○ Valor Mensal: R$ 300,00. Se o veículo tiver freios ABS e Airbag,
conceda um desconto de R$ 30,00.
3. Risco Baixo: Motoristas com 25 anos ou mais e com histórico zerado de
acidentes.
○ Mensagem: "Perfil de Risco Baixo (Excelente Condutor)."
○ Valor Mensal: R$ 180,00.
Entradas:
● idade
● historicoAcidentes
● possuiItensSeguranca
Saídas:
● Categoria de risco do motorista.
● Valor final da mensalidade do seguro.*/