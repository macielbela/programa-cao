let kwh= parseFloat(prompt("Quanto é seu total de energia? em kwh"))
let opcao= prompt("Qual é a categoria que você usa? R(residencial), C(comercial ou I (industrial)?").toUpperCase()
let tarifa

switch (opcao) {
    case "R":
        tarifa= 0.75*kwh
        alert (`O resultado da sua conta com a tarifa de R$0.75 por kwh é de ${tarifa+kwh}`)
        break
    case "C":
        tarifa= 0.92*kwh
        alert (`O resultado da sua conta com a tarifa de R$0.92 por kwh é de ${tarifa+kwh}`)
        break
    case "I":
        tarifa= 0.68*kwh
        alert (`O resultado da sua conta com a tarifa de R$0.68 por kwh é de ${tarifa+kwh}`)
        break
    default:
        alert(`Escolha uma opcão válida pelo amor de Deus`)
}

/*Uma concessionária de energia elétrica utiliza diferentes tarifas de cobrança de acordo
com a categoria do consumidor. Para calcular o valor da conta de energia, o sistema deve
identificar a categoria informada e aplicar a tarifa correspondente ao consumo em
quilowatt-hora (kWh).
Desenvolva um programa em JavaScript que solicite ao usuário a categoria da unidade
consumidora e a quantidade de energia consumida (em kWh). Utilize a estrutura
switch para identificar a categoria e calcular o valor total da conta de energia.
Tabela de categorias e tarifas:
Categoria Descrição Tarifa por kWh
R Residencial R$ 0,75
C Comercial R$ 0,92
I Industrial R$ 0,68
Regras:
• Solicite ao usuário a categoria (R, C ou I).
• Solicite a quantidade de energia consumida em kWh.
• Calcule o valor da conta utilizando a fórmula:*/