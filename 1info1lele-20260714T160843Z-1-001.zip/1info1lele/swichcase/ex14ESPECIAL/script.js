let saldo= parseFloat(prompt("Insira seu saldo"))
let opcao= parseInt(prompt("Código, 1 para consultar o saldo, 2 para fazer um saque e 3 para realizar um depósito"))
let conta

switch (opcao) {
    case 1:
        alert (`Seu saldo é R$${saldo}`)
        break
    case 2:
        conta= parseFloat(prompt("Quanto você quer retirar?"))
            if (conta>saldo) {
                alert(`Valor maior do que o saldo, impossível de fazer a operação`)
            }
            else {
                alert(`Saque realizado, saldo total foi de R$${saldo-conta}`)
            }
        break
    case 3:
                conta= parseFloat(prompt("Quanto você quer depositar?"))
        alert (`Depósito realizado, saldo total foi de R$${saldo+conta}`)
        break

    default:
        alert(`Número válido pelo amor de Deus`)
}
