let opcao= prompt("Qual sua região? S(sul), N(norte), SE(sudeste),CO(Centro oeste) ou NE (nordeste)").toUpperCase()

switch (opcao) {
    case "S":
        alert (`Frete de R$20,00`)
        break
    case "N":
        alert(`Frete de R$45,00`)
        break
    case "SE":
        alert (`Frete de R$25,00`)
        break
    case "CO":
        alert (`Frete de R$35,00`)
        break
    case "NE":
        alert (`Frete de R$40,00`)
        break

    default:
        alert(`Região válida pelo amor de Deus`)
}

/*Desenvolva um programa em JavaScript que solicite ao usuário a sigla da região de
entrega. Utilize a estrutura switch para identificar a região correspondente e calcular o
valor do frete.
Tabela de regiões e valores do frete:
Sigla Região Valor do Frete
S Sul R$ 20,00
N Norte R$ 45,00
SE Sudeste R$ 25,00
CO Centro-Oeste R$ 35,00
NE Nordeste R$ 40,00
Regras
• Solicite ao usuário a sigla da região (S, N, SE, CO ou NE).
• Utilize a estrutura switch para identificar a região.
• Exiba:
• o nome da região;
• o valor do frete correspondente.
Observação: Considere que o usuário pode informar a sigla em letras
maiúsculas ou minúsculas.*/