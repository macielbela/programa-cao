let opcao= prompt("Qual vai ser a opção de conversão? Km (km-->m) ou m (m-->km)").toUpperCase()
let dist
let convertido

switch (opcao) {
    case "KM":
        dist= parseFloat(prompt("Quantos km você percorreu?"))
        alert (`Sua distância em km para metros foi de ${dist}Km para ${dist*1000}m`)
        break
    case "M":
        dist= parseFloat(prompt("Quantos metros você percorreu?"))
        alert (`Sua distância em km para metros foi de ${dist}m para ${dist/1000}Km`)
        break
    default:
        alert(`Escolha uma opcão válida pelo amor de Deus`)
}