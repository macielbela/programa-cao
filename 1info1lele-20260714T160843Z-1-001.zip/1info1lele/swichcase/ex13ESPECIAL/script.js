let opcao= parseInt(prompt("Número entre 1 e 5"))

switch (opcao) {
    case 1:
        alert (`Norte`)
        break
    case 2:
        alert (`Nordeste`)
        break
    case 3:
        alert (`Centro-Oeste`)
        break
    case 4:
        alert (`Sudeste`)
        break
    case 5:
        alert (`Sul`)
        break

    default:
        alert(`Número válido pelo amor de Deus`)
}
