let n1 = parseFloat(prompt("Insira um número"));
let n2 = parseFloat(prompt("Insira mais um número"));
let opera = prompt("Insira a operação matemática que vai ser utilizada. Só pode *,+,-, e /");

switch (opera) {
    case "*":
        alert("A multiplicação é" + (n1 * n2));
        break;
    case "+":
        alert("A soma é" + (n1 + n2));
        break;
    case "-":
        alert("A subtração é" + (n1 - n2));
        break;
    case "/":
        alert("A divisão é" + (n1 / n2));
        break;
    default:
        alert(`Insira uma operação válida pelo amor de Deus`);
}