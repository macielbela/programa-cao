let cod= prompt("Insira o código do seu veículo") .toUpperCase()

switch(cod) {
    case "M":
        alert(`Motocicleta`)
        break
    case "C":
        alert(`Carro`)
        break
    case "B":
        alert(`Bicicleta`)
        break
    default:
        alert(`Veículo inválido pelo amor de Deus`)
}





