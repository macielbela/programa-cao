let valor= parseFloat(prompt("Valor do desconto"))
let opcao= prompt("Você é A, B ou C ").toUpperCase()
let desconto

switch (opcao) {
    case "A":
        desconto= 0.05*valor
        alert (`O resultado da sua conta com a tarifa de R$0.75 por kwh é de ${desconto-valor}`)
        break
    case "B":
        desconto= 0.10*valor
        alert (`O resultado da sua conta com a tarifa de R$0.92 por kwh é de ${desconto-valor}`)
        break
    case "C":
        desconto= 0.15*valor
        alert (`O resultado da sua conta com a tarifa de R$0.68 por kwh é de ${desconto-valor}`)
        break
    default:
        alert(`Escolha uma opcão válida pelo amor de Deus`)
}

/*Uma concessionária de energia elétrica utiliza diferentes tarifas de cobrança de acordo
com a categoria do consumidor. Para calcular o valor da conta de energia, o sistema deve
identificar a categoria informada e aplicar a tarifa correspondente ao consumo em
quilowatt-hora (kWh).
Desenvolva um programa em JavaScript que solicite ao usuário a categoria da unidade
consumidora e a quantidade de energia consumida (em kWh). Utilize a estrutura
switch para identificar a categoria e calcular o valor total da conta de energia.
Tabela de categorias e tarifas:
Categoria Descrição Tarifa por kWh
R Residencial R$ 0,75
C Comercial R$ 0,92
I Industrial R$ 0,68
Regras:
• Solicite ao usuário a categoria (R, C ou I).
• Solicite a quantidade de energia consumida em kWh.
• Calcule o valor da conta utilizando a fórmula:*/