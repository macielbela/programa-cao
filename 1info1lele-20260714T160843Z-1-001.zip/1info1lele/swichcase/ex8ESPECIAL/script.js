let cod= parseInt(prompt("Insira o código do curso que você vai fazer"))

switch(cod) {
    case 1:
        alert(`Curso de Informática`)
        break
    case 2:
        alert(`Curso de Administração`)
        break
    case 3:
        alert(`Curso de Redes de Computadores`)
        break
    default:
        alert(`Código de curso inválido`)
}





/*Desenvolva um programa em JavaScript que solicite ao usuário o código do curso
desejado. Utilize a estrutura switch para identificar a opção escolhida e exibir o nome do
curso correspondente.
Código Curso
1 Informática
2 Administração
3 Redes de Computadores
Caso o usuário informe um código diferente dos apresentados na tabela, o programa
deverá exibir a mensagem: "Código de curso inválido."*/