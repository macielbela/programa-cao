let cod= parseInt(prompt("Insira o horário, 1(Água), 2(Refri) e 3(Suco)"))
switch (cod) {
    case 1:
        alert(`Vai tomar água e se hidratar por favor`)
        break
    case 2:
        alert(`Vai tomar suco e se hidrate por favor`)
        break
    case 3:
        alert(`Tome um refri mas logo depois tome água por favor`)
        break
    default:
        alert(`Bebida válida pelo amor de Deus`)
}