let cod= parseInt(prompt("Insira o código do produto: "))
switch (cod) {
    case 100:
        alert(`Mouse, R$600`)
        break
    case 200:
        alert(`Teclado, R$400`)
        break
    case 300:
        alert(`Monitor, R$1.700`)
        break
    default:
        alert(`Produto válido pelo amor de Deus`)
}