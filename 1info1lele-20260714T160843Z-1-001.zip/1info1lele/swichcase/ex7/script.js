let cod = parseInt(prompt("Insira a opção para a conta que quer realizar. 1(quadrado ou retângulo), 2(círculo) ou 3 (triângulo)"))
let n1
let n2
switch (cod) {
    case 1:
        n1 = parseFloat(prompt("Quadrado ou retângulo , ok, Insira primeiro valor"))
        n2 = parseFloat(prompt("Segundo valor"))
        alert(`A área é: ${n1 * n2} m²`)
        break;
    case 2:
        n1 = parseFloat(prompt("Círculo, ok, Insira o valor do raio"))
        alert(`A área é: ${(n1 ** 2) * 3.14}m²`)
        break;
    case 3:
        n1 = parseFloat(prompt("Triângulo, ok, Insira primeiro valor"))
        n2 = parseFloat(prompt("Segundo valor"))
        alert(`A área é: ${(n1 + n2) / 2}m²`)
        break;
    default:
        alert(`Paralelepípedo válido pelo amor de Deus`)
}


