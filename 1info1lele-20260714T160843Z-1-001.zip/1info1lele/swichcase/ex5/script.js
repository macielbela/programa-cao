let cod= parseInt(prompt("Insira o número do mês, 1 a 12. (Sendo 1 janeiro e 12 dezembro)"))
switch (cod) {
    case 1:
        alert(`Janeiro`)
        break
    case 2:
        alert(`Fevereiro (Aniversário do George Harrison)`)
        break
    case 3:
        alert(`Março`)
        break
    case 4:
        alert(`Abril`)
        break
    case 5:
        alert(`Maio`)
        break
    case 6:
        alert(`Junho (Aniversário do Paul McCartney)`)
        break
    case 7:
        alert(`Julho (Anivers[ario do Ringo)`)
        break
    case 8:
        alert(`Agosto`)
        break
    case 9:
        alert(`Setembro`)
        break
    case 10:
        alert(`Outubro (Aniversário do John Lennon)`)
        break
    case 11:
        alert(`Novembro`)
        break
    case 12:
        alert(`Dezembro`)
        break
    default:
        alert(`Mês válido pelo amor de Deus`)
}