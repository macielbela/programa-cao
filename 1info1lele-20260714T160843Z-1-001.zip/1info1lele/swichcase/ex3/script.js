let cod= prompt("Insira o horário, M(manhã), T(tarde) e N(noite)") .toUpperCase()
switch (cod) {
    case "M":
        alert(`Período da manhã, bom dia`)
        break
    case "T":
        alert(`Período da tarde, boa tarde`)
        break
    case "N":
        alert(`Período da noite, boa noite`)
        break
    default:
        alert(`Insira um período válido pelo amor de Deus`)
}